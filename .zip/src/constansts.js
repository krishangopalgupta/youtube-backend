export const DB_NAME = 'Videotube';
